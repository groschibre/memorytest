var nb1;
var nb2;
function AccesProtege() 
{ 	nb2=document.getElementById("n3").value;
	self.location.href=nb2+".html"; }
