var nb2;
function AccesProtege() 
{ 	nb2=document.getElementById("n3").value;
	self.location.href="Menu/"+nb2+".html"; }